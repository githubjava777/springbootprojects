package com.example.springbootwithrest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootwithrestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootwithrestApplication.class, args);
	}

}
