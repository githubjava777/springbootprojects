package com.example.springbootwithrest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeController {
	
	@Autowired
	EmployeeServiceStub employeeServiceStub;

	
	@GetMapping("/employees")
	public List<Employee>  getAllEmployees()
	{
		return employeeServiceStub.getAllEmployees();
		
		
	}
	
	
	@PostMapping("/addEmployee")
	public String  addEmployee()
	{
		return "saved";
		
		
	}
	
	@PutMapping("/updateEmployee")
	public String  updateEmployee()
	{
		return "updated";
		
		
	}
	
	
	@DeleteMapping("/deleteEmployee")
	public String  deleteEmployee()
	{
		return "deleted employee";
		
		
	}
	
	
}
