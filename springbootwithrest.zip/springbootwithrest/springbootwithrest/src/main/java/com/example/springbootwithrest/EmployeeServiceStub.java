package com.example.springbootwithrest;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class EmployeeServiceStub {

	
	public List<Employee>  getAllEmployees()
	{
		
		ArrayList<Employee> employees = new ArrayList<Employee>();  
		employees.add(new Employee(1l,"abc","12345",10000l));
		employees.add(new Employee(2l,"abcd","123456",11000l));
		employees.add(new Employee(3l,"abcde","1234567",12000l));
		return employees;
		
		
	}
}
