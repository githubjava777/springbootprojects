package com.example.springbootwithrest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootwithrestApplicationTests {

	@Test
	void contextLoads() {
	}

}
