package com.FirstSpringBootApp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class TestController {

	@GetMapping("p1")
	public String Demopage1()
	{
		return "Page1";
	}
	
	@GetMapping("p2")
	public String Demopage2()
	{
		return "Page2";
	}
	
	@GetMapping("log")
	public String LoginPage()
	{
		return "Login";
	}
	
	@PostMapping("logprocess")
	public String LoginPage(@RequestParam String txtUser, 
			@RequestParam String txtPass, Model m)
	{
		System.out.println(txtUser + "\t" + txtPass);
		if(txtUser.equals("venugopal") && txtPass.equals("12345"))
			return "Welcome";
		else
		{
			m.addAttribute("info", "Please check username/password");
		}
		return "Login";
	}
}
