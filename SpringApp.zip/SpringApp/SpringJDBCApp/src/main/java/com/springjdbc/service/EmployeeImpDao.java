package com.springjdbc.service;

import java.util.List;
import java.util.jar.Attributes.Name;

import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import com.google.protobuf.DescriptorProtos.MethodOptions.IdempotencyLevel;
import com.springjdbc.Employee;

public class EmployeeImpDao implements EmployeeDao {	
	public DataSource dataSource ;
	public JdbcTemplate jt;
	public DataSource getDataSource() {
		return dataSource;
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		jt =new JdbcTemplate (dataSource);
	}
	public String AddEmployee(Employee emp) {
		String sql = " INSERT INTO EMPLOYEE (name , salary , location) values (?,?,?)";
		
		int res= jt.update(sql,new Object[] {emp.getName(),emp.getSalary(),emp.getLocation()});
		
		if (res>=1) 
			return "Added Successfully";
		else 
			return "Error";	
	}
	public List<Employee> ShowAll() {
		String sql = "Select * From employee";
		List<Employee> empl = jt.query(sql,new BeanPropertyRowMapper(Employee.class));
		
		return empl;
	}

	
	public Employee searchEmployee(int id) {
		String sql = "Select * from employee where id=?";
		Employee epl = null;
		try {
			epl = jt.queryForObject(sql,new Object[] {id} , new BeanPropertyRowMapper(Employee.class));
			
		} catch (Exception e) {
		   epl = null;
		}
		return epl;
	}

	public String ModifyEmployee(Employee emp) {
		String sql = "Update employee set name=? where id=?";
		int r = jt.update(sql, new Object [] {emp.getName() , emp.getId()});
		
		if(r>=1) 
			return "Updated..."; 
		else 
			return "Not Updated..";
	}

	public String deleteEmployee(int id) {
		String sql = "Delete from employee  where id=?";
		int r = jt.update(sql, new Object [] {id});
		
		if(r>=1) 
			return "Deleted..."; 
		else 
			return "Not Deleted..";
		
	}

}
