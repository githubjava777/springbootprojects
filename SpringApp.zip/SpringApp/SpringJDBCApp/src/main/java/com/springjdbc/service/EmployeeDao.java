package com.springjdbc.service;

import java.util.List;

import com.springjdbc.Employee;


public interface EmployeeDao {
	

	public String  AddEmployee(Employee emp);
	public List<Employee> ShowAll();
	public  Employee searchEmployee(int id);
	public String ModifyEmployee(Employee emp);
	public String deleteEmployee (int id);
	
	}
