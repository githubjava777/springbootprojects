package com.springjdbc.test;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.springjdbc.Employee;
import com.springjdbc.service.EmployeeDao;

public class EmployeeMainTest {

	public static void main(String[] args) {

		
		ApplicationContext context = new ClassPathXmlApplicationContext("JDBCConfigure.xml");
		EmployeeDao ed = (EmployeeDao) context.getBean("empObj");
		Scanner sc = new Scanner(System.in);
		Employee em = new Employee();
		
		while (true) {
			System.out.println("1. Add\n2. Show All\n3. Search\n4. Modify\n5. Delete\n6. Exit");
			System.out.println("Enter Your Choice:");
			int ch = sc.nextInt();
		 switch (ch) {
		 
		case 1:
			
				System.out.println("Enter Employee Name:");
				em.setName(sc.next());
				System.out.println("Employee Salary:");
				em.setSalary(sc.nextFloat());
				System.out.println("Work Location:");
				em.setLocation(sc.next());
				System.out.println(ed.AddEmployee(em));
				
			break;
			
		case 2:
			
				List<Employee> listall = ed.ShowAll();
				 for (Employee empe: listall)
				 {
					 System.out.println(empe.getName()+"\t"+empe.getSalary()+"\t"+empe.getLocation());
				 }
			break;
			
		case 3:
			
				System.out.println("Enter Employee ID:");
				int id= sc.nextInt();
				Employee emply = ed.searchEmployee(id);
				
				if (emply!=null) {
					 System.out.println(emply.getName()+"\t"+emply.getSalary()+"\t"+emply.getLocation());
				}
				else {
					System.out.println("Enter Valid ID...");
				}
			break;
			
		case 4:
			
				System.out.println("Enter Employee ID:");
				int eid= sc.nextInt();
				Employee emp1 = ed.searchEmployee(eid);
				
				if (emp1!=null) {
					 System.out.println("Employee Prasent Name: "+emp1.getName());
					 System.out.println("New Name For Employee:");
					 emp1.setName(sc.next());
					 System.out.println(ed.ModifyEmployee(emp1));
				}
				else {
					System.out.println("Enter Valid ID...");
				}
			break;
			
		case 5:
			
				System.out.println("Enter Employee ID To Delete:");
				int emid= sc.nextInt();
				Employee empl1 = ed.searchEmployee(emid);
				
				if (empl1!=null) {
					
					 System.out.println(empl1);
					 System.out.println("Are You Sure ..(Y/N)");
					 String s = sc.next();
					 if (s.equalsIgnoreCase("y"))
					 { 
						 System.out.println(ed.deleteEmployee(emid));
					 }
					else
					{
						System.out.println("Not Deleted...");
					}
				}
				else {
					System.out.println("Enter Valid ID...");
				}
			break;
			
		case 6:
			
			System.out.println("Thank You...");
			System.exit(0);
			break;
		
		}
	
		}
		
	}
	
}


