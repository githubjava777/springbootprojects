# Spring Boot Log4j 2

Article link : https://www.mkyong.com/spring-boot/spring-boot-log4j-2-example/