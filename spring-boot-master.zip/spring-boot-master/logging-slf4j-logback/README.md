# Spring Boot SLF4j Logback

Article link : https://www.mkyong.com/spring-boot/spring-boot-slf4j-logging-example/