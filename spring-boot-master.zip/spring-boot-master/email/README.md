# Spring Boot - How to send email via SMTP

Article link : https://www.mkyong.com/spring-boot/spring-boot-how-to-send-email-via-smtp/
