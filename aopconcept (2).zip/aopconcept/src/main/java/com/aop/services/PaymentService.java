package com.aop.services;

public interface PaymentService {

	public void makePayment();
}
