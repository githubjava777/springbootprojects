package com.aop.services;

public class PaymentServiceImpl implements PaymentService {

	public void makePayment() {
		// TODO Auto-generated method stub
		System.out.println("Amount Debited");
		
		//
		//
		System.out.println("Amount Credited");
		
		
	}

}
