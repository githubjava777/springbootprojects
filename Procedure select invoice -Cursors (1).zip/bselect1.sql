create procedure select_invoice(invoice_id in number,invoice_details out SYS_REFCURSOR)
is
begin
open invoice_details for select status, paper_invoice_batch_number from invoice where id =invoice_id;

end;