package tests;


public class UnitTesting {

public int square(int n) {
	return n*n;
}
public int sum(int a ,int b) {
	return a+b;
	
}

}
