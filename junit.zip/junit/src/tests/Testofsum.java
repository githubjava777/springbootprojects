package tests;

import static org.junit.Assert.*;

import org.junit.Test;

public class Testofsum {

	@Test
	public void test() {
	
		UnitTesting ob = new UnitTesting();
		int R = ob.sum(7, 6);
		assertEquals(13, R);
	}

}
