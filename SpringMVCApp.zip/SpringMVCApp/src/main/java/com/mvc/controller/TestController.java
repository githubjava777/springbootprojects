package com.mvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class TestController {

	@RequestMapping(value="p1",  method=RequestMethod.GET)
	public String TestPage1(Model m)
	{
		m.addAttribute("msg", "This is Msg sending from Controller to View");
		return "Page1";
	}

	@RequestMapping(value="p2",  method=RequestMethod.GET)
	public String TestPage2()
	{
		return "Page2";
	}
	
	@RequestMapping(value="log",  method=RequestMethod.GET)
	public String LoginPage()
	{
		return "Login";
	}
	
	@RequestMapping(value="logprocess",  method=RequestMethod.POST)
	public String LoginPages(@RequestParam("txtUser") String user, 
			@RequestParam("txtPass") String pass, Model m)
	{
		System.out.println(user + "\t" + pass);
		if(user.equals("venugopal") && pass.equals("12345"))
			return "Welcome";
		else
		{
			m.addAttribute("info", "Please check username/password");
		}
		return "Login";
	}
}
