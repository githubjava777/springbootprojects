create trigger check_delete
after delete on employee
for each row
begin 
insert into EMPLOYEE_ARCHIVE values(:old.EMPID,:old.EMPNAME,:old.MANAGERID,sysdate );
end;

    



        
    