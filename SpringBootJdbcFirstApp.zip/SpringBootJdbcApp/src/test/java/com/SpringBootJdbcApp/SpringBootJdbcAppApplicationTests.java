package com.SpringBootJdbcApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJdbcAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
