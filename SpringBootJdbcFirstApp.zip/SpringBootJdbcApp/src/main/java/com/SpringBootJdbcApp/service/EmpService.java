package com.SpringBootJdbcApp.service;

import java.util.List;

import com.SpringBootJdbcApp.model.Employee;

public interface EmpService {

	public String AddNewEmp(Employee emp);
	public List<Employee>  GetAll();
	public Employee SearchEmp(int eno);
}
