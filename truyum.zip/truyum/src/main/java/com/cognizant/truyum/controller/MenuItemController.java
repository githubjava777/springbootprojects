package com.cognizant.truyum.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;

import com.cognizant.truyum.service.MenuItemService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Controller
public class MenuItemController {

	private static final Logger LOGGER = LoggerFactory.getLogger(MenuItemController.class);
	/*
	 * @Autowired private MenuItemService menuItemService;
	 */

	@GetMapping("/show-menu-list-admin")
	public String showMenuItemListAdmin(ModelMap model) throws Exception {
		LOGGER.info("start");
		//menuItemService.getMenuItemListAdmin();
		// model.addAttribute("student", new Student());
		 LOGGER.info("end");
		 
		return "menu-item-list-admin";

	}
	
	@GetMapping("/show-menu-list-customer")
	public String showMenuItemListCustomer(ModelMap model) {
		 LOGGER.info("Start") ;
		 
		 
		 LOGGER.info("End");
		
		
		
		return "menu-item-list-customer";
		
		
		
		
	}
}
