package com.cognizant.truyum.service;

public class MenuItemService {

	
	public void getMenuItemListAdmin() 
	{
		
		
	}
}
