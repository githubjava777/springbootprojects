package com.SpringBootJdbcApp.entity;

/*Create table student(rollno int auto_increment primary key, 
stdname varchar(20), location varchar(20), 
email varchar(40), pasword varchar(20));
 * */
 
public class Student {

	private int rollno;
	private String stdname;
	private String location;
	private String email;
	private String pasword;
	
	public int getRollno() {
		return rollno;
	}
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	public String getStdname() {
		return stdname;
	}
	public void setStdname(String stdname) {
		this.stdname = stdname;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPasword() {
		return pasword;
	}
	public void setPasword(String pasword) {
		this.pasword = pasword;
	}
	
	
}
