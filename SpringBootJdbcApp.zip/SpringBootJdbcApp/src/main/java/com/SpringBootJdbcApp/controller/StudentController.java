package com.SpringBootJdbcApp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestParam;

import com.SpringBootJdbcApp.entity.Student;
import com.SpringBootJdbcApp.service.*;
@Controller
@ComponentScan("com.SpringBootJdbcApp")
public class StudentController {

	@Autowired
	StudentService ss;
	
	@GetMapping("/")  // loads first page
	public String loginPage()
	{
		return "Login";
	}
	
	@GetMapping("login")
	public String loginPage(Model m)
	{
		return "Login";
	}
	
	@GetMapping("nstd")
	public String newstdpage(Model m)
	{
		m.addAttribute("std", new Student());
		return "NewStudent";
	}
	
	@GetMapping("shome")
	public String studenthome(Model m)
	{		
		return "StdHome";
	}
	
	@GetMapping("sall")
	public String studentsall(Model m)
	{
		List<Student>  stdall = ss.GetAll();
		m.addAttribute("stdall", stdall);
		System.out.println(stdall);
		return "ShowAll";
	}
	
	@PostMapping("login")
	public String loginPage(@RequestParam String txtUser,
			@RequestParam String txtPass,
			Model m)
	{
		String url = "";
		
		if(txtUser.equals("Admin") && txtPass.equals("12345"))
		{
			url="redirect:sall";
		}
		else
		{
			Student std = ss.CheckUserDetails(txtUser, txtPass);
			if(std!=null)
			{
				m.addAttribute("std", std);
				url = "StdHome";
			}
			else
			{
				m.addAttribute("info", "Please check username/password");
				url = "Login";
			}

		}
		return url;
	}
	
	@PostMapping("addstd")
	public String newstdpage(@ModelAttribute  Student std, Model m)
	{
		String res = ss.AddStudent(std);
		m.addAttribute("std", new Student());
		m.addAttribute("msg", res);
		return "redirect:sall";
	}
}
