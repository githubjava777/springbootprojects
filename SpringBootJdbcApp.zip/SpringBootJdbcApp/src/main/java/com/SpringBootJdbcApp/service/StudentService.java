package com.SpringBootJdbcApp.service;
import java.util.List;

import com.SpringBootJdbcApp.entity.*;
public interface StudentService {

	public String AddStudent(Student std);
	public List<Student> GetAll();
	public Student Search(int rno);
	public Student CheckUserDetails(String user, String pwd);
}
