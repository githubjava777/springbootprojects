package com.SpringBootJdbcApp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import com.SpringBootJdbcApp.entity.Student;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	JdbcTemplate  jt;
	
	@Override
	public String AddStudent(Student std) {
		String sql = "Insert into Student(stdname, location, email, pasword) values(?,?,?,?)";
		int res = jt.update(sql, new Object[] {std.getStdname(), std.getLocation(), std.getEmail(), std.getPasword()});
		if(res>=1)
			return "New Std Added...";
		else
			return "New Std Not Added....";
	}

	@Override
	public List<Student> GetAll() {
		 String sql = "SELECT * FROM student";
	     List<Student> stdinfo = jt.query(sql, new BeanPropertyRowMapper(Student.class));
	     return stdinfo;	
	}

	@Override
	public Student Search(int rno) {
		Student std = null;
		String sql = "Select * from student where rollno=?";
		try
		{
			std = (Student)jt.queryForObject(sql, new Object[] {rno}, new BeanPropertyRowMapper(Student.class));			
		}
		catch(Exception ex)
		{
			std = null;
		}
		return std;
	}
	
	@Override
	public Student CheckUserDetails(String user, String pwd)
	{		
		Student userdetails = null;
		String sql = "Select * from student where email=? and pasword=?";
		try
		{
			userdetails = (Student)jt.queryForObject(sql, new Object[] {user, pwd}, new BeanPropertyRowMapper(Student.class));			
		}
		catch(Exception ex)
		{
			userdetails = null;
		}
		return userdetails;
	}
}
