package com.SpringBootJdbcApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJdbcAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJdbcAppApplication.class, args);
		System.out.println("Server Started.....");
	}
}
